
import React from 'react';
import { View, Text, StyleSheet, Button, Alert } from 'react-native';

export default function App() {
  const handleProfitCheck = () => {
    Alert.alert("Auto Profit", "You earned 20 USDT today!");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to DreamToRich</Text>
      <Text style={styles.subtitle}>Start your crypto journey!</Text>
      <Button title="Check Profit" onPress={handleProfitCheck} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    color: '#aaa',
    fontSize: 16,
    marginBottom: 20,
  }
});
